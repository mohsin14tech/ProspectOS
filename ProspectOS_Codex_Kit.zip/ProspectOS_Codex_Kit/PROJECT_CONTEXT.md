# ProspectOS — Project Context / Session Handoff

> **This is the canonical memory file for the repository.** Every Codex session must read it first and update it before ending. Do not rely on chat history as the only source of project context.

## 1. Product identity

- **Name:** ProspectOS
- **Owner:** 14 Technologies
- **Category:** AI business development intelligence, CRM, omnichannel engagement and automation.
- **Positioning:** AI Business Development & Omnichannel Command Centre.
- **Product promise:** Discover opportunities. Understand businesses. Build relationships. Grow intelligently.
- **Primary domain target:** `prospectos.14technologies.com` (configurable; do not assume DNS is already configured).
- **Hackathon:** Symfony AI & MCP Hackathon 2026.

ProspectOS is designed to discover businesses, research their public digital presence, find evidence-backed commercial opportunities, qualify prospects, manage a CRM/pipeline, draft personalised outreach, coordinate approved communications over connected channels, collect supported replies and report business development outcomes.

It is not merely a lead scraper, bulk email sender, chatbot or static dashboard.

## 2. Primary end-to-end user journey

1. User enters a natural-language business development/research objective.
2. ProspectOS plans and runs a research job asynchronously.
3. Search adapters discover candidate businesses.
4. Safe website inspection extracts public, observable signals.
5. Every important finding is stored with source URL, excerpt/value, timestamp and confidence.
6. A deterministic scoring service calculates an explainable 0–100 opportunity score.
7. An AI agent creates a prospect report grounded in stored evidence.
8. The application drafts personalised communication based on verified findings.
9. The user reviews and explicitly approves external outreach by default.
10. The selected official provider adapter sends the message, if permissions and policy allow it.
11. Provider webhooks/APIs synchronise supported replies and delivery events.
12. The prospect, conversation, activity timeline, campaign and analytics update.

## 3. Fixed architecture decisions

| Area | Decision |
|---|---|
| Backend | Symfony full-stack |
| PHP target | PHP 8.4 if compatible with pinned Symfony AI/MCP packages and Upsun runtime |
| Symfony framework | Prefer stable 8.1 where compatible; fallback to maintained 7.4 LTS if the prerelease packages require it; verify and record exact choice |
| UI | Twig + Symfony UX + Stimulus + Turbo |
| CSS | Tailwind CSS with central design tokens |
| Database | PostgreSQL + Doctrine ORM/Migrations |
| Background processing | Symfony Messenger with separate worker process |
| Queue | PostgreSQL/Doctrine as reliable initial transport; Redis transport when properly provisioned/tested |
| Cache/limits | Redis where available; don't make nonessential Redis a hard blocker |
| AI | Symfony AI; Hugging Face Inference Providers is the hackathon credit path |
| MCP | Official `mcp/sdk` through `symfony/mcp-bundle`, after checking exact compatibility |
| Integrations | OAuth, API credentials, webhooks, generic REST/OpenAPI, remote MCP and native adapters |
| Hosting | Upsun |
| Source / CI | Public GitHub monorepo + GitHub Actions |
| Mobile | Installable responsive PWA from same Symfony app |
| WordPress | Not the app framework; existing 14 Technologies WordPress website remains separate |
| Cloudflare Pages | Not required for the core app; Upsun hosts Symfony |

The Symfony AI and MCP packages are in the hackathon pre-release period. Pin compatible versions in `composer.lock`, preserve reproducible installation, and record versions here after implementation.

## 4. Required integrations and extensibility

The Integration Hub must make connections straightforward but must not pretend every provider accepts just an API key. Support multiple connection mechanisms:

- OAuth 2.0 (Authorization Code, PKCE where applicable, state validation, scopes, refresh/revoke).
- API credentials (Bearer, header API key, Basic, provider-specific fields, OAuth client credentials or HMAC where relevant).
- Inbound webhooks (verification/challenge, signatures, replay protection, idempotency, async handling and event logs).
- Outbound signed webhooks (event selection, HMAC, retries and delivery logs).
- Generic REST/OpenAPI connector (operation allowlist, schemas, field mapping, test requests and SSRF protection).
- Remote MCP client (discover tools/resources/prompts, allowlist selected capabilities, authenticate and log invocations).
- Native provider adapters.

Provider targets:

- Email: SMTP outbound; Gmail API; Microsoft Graph; optional IMAP/provider inbound events.
- WhatsApp: official WhatsApp Business Platform Cloud API.
- Facebook Pages/Messenger: official Graph API and only granted capabilities.
- Instagram Professional: official Meta APIs and only permitted operations.
- LinkedIn: authorised organisation publishing/data where approved; no scraping or unauthorised personal DMs.
- Telegram Bot API: only permitted bot conversations.
- Search: pluggable business/web search providers such as Brave Search, Tavily or SerpAPI.
- Productivity/CRM extensions: Google Sheets, Google Calendar, HubSpot, Pipedrive, Slack.
- AI: Hugging Face Inference Providers; optional OpenAI/Anthropic BYOK.

Never claim a provider is live until a real operation is tested. Display connection state, granted scopes, supported capabilities and limitations honestly. Native integrations require provider permission/account prerequisites. Generic API/OpenAPI support is an extensibility layer, not a guarantee that every API can be automatically understood.

## 5. AI and scoring rules

- Use Symfony AI agent/platform components for actual model inference and tool calling.
- Hugging Face hackathon coupon is $20 per developer after registration, subject to dashboard/terms. Route eligible inference through HF Inference Providers to use the credits; do not hardcode a model until tool calling/task support is verified.
- Track model/provider, run ID, latency and usage/cost where available.
- Keep prompt sizes and tool loops bounded.
- Use deterministic code for score calculation.
- Initial scoring weights: ICP fit 25%, observable opportunity 30%, evidence quality 20%, contactability 15%, intent/recency 10%.
- Unknowns must not silently count as negative evidence; show confidence, evidence coverage and freshness separately.
- AI claims must refer to evidence records; never invent contact details, facts, source URLs or excerpts.
- Treat web pages, emails, uploaded content and remote MCP responses as untrusted data and possible prompt injection.

## 6. MCP requirements

ProspectOS must be both:

- **MCP server:** expose curated, authenticated, workspace-scoped tools/resources to compatible external clients such as Claude Desktop.
- **MCP client:** connect to remote MCP servers, discover capabilities, allowlist tools and log invocations.

Suggested tools include search/get prospect, get evidence, analyse website, score prospect, create outreach draft, request approval, get approval status, create follow-up task, search conversations and get campaign metrics.

A sending tool must require a valid, unexpired human approval record bound to an immutable action payload. A model/client cannot approve its own action. No unauthenticated MCP endpoint, arbitrary SQL, filesystem, shell or generic unrestricted HTTP tool.

## 7. Visual/UI direction

Two supplied reference files are mandatory:

- `docs/reference/app-ui-ux-skill.md` — UX authority. Follow its one-screen/one-job/one-primary-action philosophy, progressive disclosure, mobile-first 390px baseline, spacing/radius/type scales, accessibility and interaction-state rules.
- `docs/reference/dashboard-visual-reference.png` — visual reference for pale powder-blue canvas, white cards, navy/cobalt charts, stacked horizontal bars, donut/ring chart, line trend, positive/negative diverging bars and compact ranked comparisons.

Starting estimated palette:

- Canvas `#E9F3FF`
- Surface `#FFFFFF`
- Muted surface `#F5F7FB`
- Ink `#17233D`
- Navy `#061C75`
- Primary cobalt `#001DBF`
- Secondary blue `#204DDE`
- Soft blue `#A9C5F5`
- Border `#DCE4F0`
- Negative `#E84B55`
- Positive `#23865A`
- Rare highlight `#D5A52B`

Centralise tokens and verify contrast. Default light theme. No decorative gradients/glass effects. Use chart colours consistently, label chart values, support accessible summaries and make data responsive.

## 8. Core modules

- Command Centre.
- AI Research Workspace.
- Prospects CRM and detail/evidence report.
- Campaigns and sequences.
- Unified Inbox.
- Social Studio (only supported publishing operations).
- Approvals.
- Tasks/follow-ups.
- Analytics.
- Integration Hub.
- AI Workbench/agent run logs.
- Settings/team/workspace.

Mobile PWA prioritises dashboard summary, inbox, prospect detail, approvals and tasks.

## 9. Security and outreach policy

- Workspace-scoped data access and role checks on every route/service/tool.
- Encrypt credentials at rest with key stored outside source control.
- Never re-display stored secrets or log credentials.
- OAuth state/PKCE as supported, strict redirect URI checks and token refresh/revoke.
- Webhook signature verification, idempotency, replay protection and event logs.
- SSRF protection for website inspection and generic API base URLs; block private/internal/metadata IPs, unsafe redirects, arbitrary ports and unsafe schemes.
- Outbound communications require approval by default, provider policy checks, sending limits, suppression/opt-out checks and audit logs.
- WhatsApp/Meta/LinkedIn constraints must be checked in official live documentation during implementation.
- No unofficial WhatsApp Web automation, social scraping, CAPTCHA bypass or unauthorised cold DMs.
- Global outbound pause/kill switch.

## 10. Hosting and operations

- Upsun hosts the Symfony app.
- GitHub is the public source and CI repository.
- PostgreSQL is the primary database.
- Dedicated worker for Messenger; use scheduler/cron only for scheduled tasks.
- Redis is optional depending on selected service/plan and should not be a production queue dependency unless persistence/availability is configured.
- Local Docker Compose setup.
- `.env.example` with placeholders only.
- Health check, safe migrations, logs, backups and deployment rollback notes.
- PWA uses offline cache only for shell/static non-sensitive assets; never cache secrets or private conversations by default.

## 11. Hackathon scope and deadline

Hackathon deliverables: public GitHub repository and 90-second real-product demo video. Submission deadline: 22 November 2026 at 18:00 CET / 22:00 Pakistan time.

Priority demo flow:

Research objective → real Symfony AI tool execution → evidence-backed prospect report → deterministic score → outreach draft → approval → safe/test send → activity history → MCP external client call.

Complete this vertical slice before expanding every named provider integration. Mark simulated records/actions clearly and keep live and demo analytics separate.

## 12. Continuity and current state

**Initial status at kit creation:** Product architecture and scope agreed; implementation has not yet been performed by Codex. No provider credentials, GitHub repository, Upsun project, DNS, Meta app, Gmail OAuth app or LinkedIn app should be assumed to exist.

At each work session, Codex must replace this paragraph with actual implementation status and retain a concise history. Record:

- Exact framework/package versions and why selected.
- Current branch/commit if available.
- Completed modules and important file paths.
- Database migration state.
- Tests executed and results.
- Deployment state and URL if verified.
- Connected live providers and the exact capabilities actually tested.
- Missing credentials / app-review prerequisites.
- Known bugs and limitations.
- Next 3–7 concrete tasks in priority order.

Do not state “deployed”, “connected”, “working” or “complete” unless verified. When a Codex session ends, update this file and `CODEX_PROGRESS.md`.

## 13. Canonical build brief

Read and execute `CODEX_MASTER_BUILD_PROMPT.md`. It is the detailed implementation contract and contains screens, connector architecture, security rules, MCP capabilities, tests, deployment, phases and definition of done.
