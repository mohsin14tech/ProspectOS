PROSPECTOS CODEX KIT

Contents:
- CODEX_MASTER_BUILD_PROMPT.md: the detailed Codex implementation brief.
- docs/reference/app-ui-ux-skill.md: supplied UX rules and component/design guidance.
- docs/reference/dashboard-visual-reference.png: supplied blue/white dashboard and chart reference.

How to use:
1. Create/open your ProspectOS GitHub repository locally.
2. Copy the contents of this kit into the repository root, preserving the docs/reference paths.
3. Open the repository in Codex.
4. Give Codex the CODEX_MASTER_BUILD_PROMPT.md and instruct it to execute it, not merely summarise it.
5. Ensure Codex reads both reference files before UI implementation.

The prompt requires Codex to create and maintain AGENTS.md, PROJECT_CONTEXT.md, CODEX_PROGRESS.md and project documentation so future sessions retain the full context.

No API keys or credentials are included in this kit.
